﻿# Git Force-Push Recovery

## Overview
Recover three orphaned commits lost to an accidental `git push --force`.
The workflow is self-contained and must run without network access after the zip is unpacked.

## Files
| Path | Role |
|---|---|
| `orphaned_object_store/.git/objects` | Dangling loose Git objects with no refs pointing at the lost commits |
| `repo_after_force.bundle` | Git bundle taken after force push; contains only surviving refs |
| `reflog_export.txt` | Reflog entries showing lost SHAs |
| `commit_graph_spec.json` | Expected commit topology |
| `expected_file_checksums.json` | File checksums per commit |
| `expected_refs.json` | Expected branch ref SHAs |
| `output_schemas/repair_log.schema.json` | JSON Schema for outputs/repair_log.json |
| `output_schemas/commit_graph_report.schema.json` | JSON Schema for outputs/commit_graph_report.json |
| `output_schemas/run_manifest.schema.json` | JSON Schema for outputs/run_manifest.json |
| `verifier_inputs/normal_recovery_case.json` | Normal-case fixture describing a clean recovery |
| `verifier_inputs/edge_partial_overlap_case.json` | Edge-case fixture: orphan ancestors only recoverable from dangling loose objects |
| `verifier_inputs/invalid_corrupted_bundle_case.json` | Invalid-case fixture: missing/corrupt loose object store, solver must fail loudly |
| `version_manifest.json` | Runtime and package manifest |

## Expected outputs
- `outputs/repaired_repo.bundle`
- `outputs/repair_log.json`
- `outputs/commit_graph_report.json`
- `outputs/run_manifest.json`

## Provenance
All repository contents and fixtures are synthetic, locally constructed for this force-push recovery scenario, and have no licensing restrictions.

## SHA-256 checksums
| Path | SHA-256 |
|---|---|
| `orphaned_object_store/.git/objects` | 482006265fd8fa66881b7a502a439176e1af947b01d888d09a607d6e7337298c |
| `repo_after_force.bundle` | 8ed9a916a8fbbe3b437508eb8c86d92bf9066d654e2f29ae1b660c9287043a2d |
| `reflog_export.txt` | 9b96bda35b02a7578b0931d5115195ab51ebd8f5ee25145666c70cc5f4d4909a |
| `commit_graph_spec.json` | a728998e8f9f99cf915a84ba657eb5646ca315545f589593104686299964da33 |
| `expected_file_checksums.json` | 4485ae7dca9c7ee2a3b9a437233c045c0cc495e5703422ff1c190989919f0823 |
| `expected_refs.json` | 356f64317a79daf4e8e79757b8229eb93bed2e95b8dc268155f4e4131bd69d92 |
| `output_schemas/repair_log.schema.json` | 1c3893d9ce44b03fd3e7d745a18480f1ecfb21efaea64b5e02c229ae389e2749 |
| `output_schemas/commit_graph_report.schema.json` | 896637e6cf540fab79493980057e63f4919bb141d72eb96908dc8087a783aaa3 |
| `output_schemas/run_manifest.schema.json` | 81cbcb493d206323924992958e063438a66d932bd73c097461a3e6cf3732e7bc |
| `verifier_inputs/normal_recovery_case.json` | b292c5bd619786799cf6415bde60c94ebdb94a490aa64da7001baf9f8e738245 |
| `verifier_inputs/edge_partial_overlap_case.json` | 793c8ff8a6a0600ac75e18639aae0f240b00d2f79bd5cb542081b6f9aba163e0 |
| `verifier_inputs/invalid_corrupted_bundle_case.json` | 562117313b08fe3fd41a2001b19e51d6518cba23012f1c94c0658dad4784296e |
| `version_manifest.json` | e88d53f2544e3fbc9707739ac366103fca4e3bb949628a711718159a0a66811c |

