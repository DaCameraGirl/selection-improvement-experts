#!/usr/bin/env python3
"""Verify: Check repaired bundle validity, commit topology, and checksums."""
import sys, json, subprocess, tempfile, os, shutil, re, stat
from pathlib import Path
import platform
GIT = 'git.exe' if platform.system() == 'Windows' else 'git'

errors = []

required_outputs = [
    "outputs/repaired_repo.bundle",
    "outputs/repair_log.json",
    "outputs/commit_graph_report.json",
    "outputs/run_manifest.json"
]

for ro in required_outputs:
    p = Path(ro)
    if not p.exists():
        errors.append(f"Missing required output: {ro} (MISSING_FILE)")
    elif p.is_file() and p.stat().st_size == 0:
        errors.append(f"Required output is empty: {ro} (MISSING_FILE)")

if errors:
    for e in errors:
        print(f"FAIL: {e}")
    sys.exit(1)

# ---- Check 1: repaired_repo.bundle is valid and cloneable ----
def git(args, cwd=None):
    return subprocess.run([GIT] + args, capture_output=True, text=True, encoding='utf-8', errors='replace', cwd=cwd)

def load_json(path):
    try:
        return json.loads(Path(path).read_text())
    except Exception as exc:
        errors.append(f'{path}: invalid JSON: {exc} (SCHEMA_INVALID)')
        return {}

with tempfile.TemporaryDirectory() as td:
    clone = git(["clone", "outputs/repaired_repo.bundle", td])
    if clone.returncode != 0:
        errors.append("repaired_repo.bundle: git clone failed")

    if not errors:
        fsck = git(["fsck", "--connectivity-only"], cwd=td)
        if fsck.returncode != 0:
            errors.append("repaired_repo.bundle: git fsck --connectivity-only reports missing or corrupt objects")

# ---- Check 2: repair_log.json all refs restored ----
repair_log = load_json('outputs/repair_log.json')
expected_refs_path = Path('expected_refs.json')
if expected_refs_path.exists():
    expected_refs = load_json(expected_refs_path)
    restored = set(repair_log.get('refs_restored', {}).keys())
    expected = set(expected_refs.keys())
    if restored != expected:
        errors.append(f"Refs restored {restored} do not match expected {expected}")
    for ref, sha in expected_refs.items():
        actual = repair_log.get('refs_restored', {}).get(ref, '')
        if actual != sha:
            errors.append(f"{ref}: expected SHA {sha}, got {actual}")

# ---- Check 3: commit_graph_report.json topology matches spec ----
graph_report = load_json('outputs/commit_graph_report.json')
spec_path = Path('commit_graph_spec.json')
if spec_path.exists():
    spec = load_json(spec_path)
    for branch, info in spec.get('branches', {}).items():
        branch_report = graph_report.get('branches', {}).get(branch, {})
        if not branch_report.get('all_reachable'):
            errors.append(f"{branch}: not all expected ancestors are reachable")
        expected_ancestors = set(a[:7] for a in info.get('expected_ancestors', []))
        found_ancestors = set(branch_report.get('found_ancestors', []))
        missing = expected_ancestors - found_ancestors
        if missing:
            errors.append(f"{branch}: missing expected ancestors {missing}")

# ---- Check 4: checksums ----
checksums = repair_log.get('checksums', {})
for sha, files in checksums.items():
    for fpath, result in files.items():
        if result.get('status') == 'mismatch':
            errors.append(f"{sha}:{fpath} checksum mismatch (expected {result['expected']}, got {result['actual']})")
        elif result.get('status') == 'file_not_found':
            errors.append(f"{sha}:{fpath} not found")
expected_checksums_path = Path('expected_file_checksums.json')
if expected_checksums_path.exists():
    expected_checksums = load_json(expected_checksums_path)
    if not isinstance(checksums, dict):
        errors.append("repair_log.checksums must be an object keyed by commit SHA (SCHEMA_INVALID)")
        checksums = {}
    for sha, files in expected_checksums.items():
        if not isinstance(files, dict):
            errors.append(f"expected_file_checksums.json entry for {sha} must be an object (CONTRACT_DRIFT)")
            continue
        reported_files = checksums.get(sha)
        if not isinstance(reported_files, dict):
            errors.append(f"repair_log.checksums missing required commit {sha} from expected_file_checksums.json (THRESHOLD_FAIL)")
            continue
        for fpath, expected_hash in files.items():
            entry = reported_files.get(fpath)
            if not isinstance(entry, dict):
                errors.append(f"repair_log.checksums missing required key {sha}:{fpath} from expected_file_checksums.json (THRESHOLD_FAIL)")
                continue
            actual_expected = entry.get('expected')
            actual = entry.get('actual')
            status = entry.get('status')
            if actual_expected != expected_hash:
                errors.append(f"{sha}:{fpath} expected checksum field {actual_expected!r} does not match contract {expected_hash!r} (THRESHOLD_FAIL)")
            if status != 'match' or actual != expected_hash:
                errors.append(f"{sha}:{fpath} must report status=match and actual={expected_hash}, got status={status!r} actual={actual!r} (THRESHOLD_FAIL)")

# ---- Check 5: normal-case fixture from verifier_inputs/ ----
normal_case_path = Path('verifier_inputs/normal_recovery_case.json')
if normal_case_path.exists():
    nc = load_json(normal_case_path)
    expected_outcome = nc.get('expected_outcome', {})
    if expected_outcome.get('all_refs_restored') is True and not repair_log.get('all_refs_restored'):
        errors.append("normal_recovery_case: repair_log.all_refs_restored is not true")
    if expected_outcome.get('bundle_created') is True and not repair_log.get('bundle_created'):
        errors.append("normal_recovery_case: repair_log.bundle_created is not true")
for fixture_name in ['edge_partial_overlap_case.json', 'invalid_corrupted_bundle_case.json']:
    fixture_path = Path('verifier_inputs') / fixture_name
    if not fixture_path.exists():
        errors.append(f'{fixture_path} missing (CONTRACT_DRIFT)')
        continue
    fixture = load_json(fixture_path)
    if not isinstance(fixture.get('must_pass_checks'), list) or not fixture.get('must_pass_checks'):
        errors.append(f'{fixture_path}.must_pass_checks must be a non-empty list (SCHEMA_INVALID)')
    if fixture_name.startswith('edge') and fixture.get('failure_mode_if_wrong_source', {}).get('reason_code') != 'TEST_FAIL':
        errors.append(f'{fixture_path} must declare TEST_FAIL for wrong-source recovery (CONTRACT_DRIFT)')
    if fixture_name.startswith('invalid') and fixture.get('expected_outcome', {}).get('verify_exit_code') != 1:
        errors.append(f'{fixture_path} must declare verify_exit_code=1 for invalid input (CONTRACT_DRIFT)')

# ---- Check 6: strict schema and type enforcement (catches superficially-correct output) ----
RL_REQUIRED = {'branches_restored', 'refs_expected', 'refs_restored', 'all_refs_restored', 'orphaned_shas', 'bundle_created', 'checksums'}
missing_rl = RL_REQUIRED - set(repair_log.keys())
if missing_rl:
    errors.append(f"repair_log.json missing required keys: {sorted(missing_rl)} (SCHEMA_INVALID)")
if not isinstance(repair_log.get('bundle_created'), bool):
    got_type = type(repair_log.get('bundle_created')).__name__
    errors.append(f"repair_log.bundle_created must be boolean, got {got_type} (SCHEMA_INVALID)")
if not isinstance(repair_log.get('all_refs_restored'), bool):
    got_type = type(repair_log.get('all_refs_restored')).__name__
    errors.append(f"repair_log.all_refs_restored must be boolean, got {got_type} (SCHEMA_INVALID)")
VALID_STATUS = {'match', 'mismatch', 'file_not_found'}
for sha, files in (repair_log.get('checksums') or {}).items():
    for fpath, entry in (files or {}).items():
        st = entry.get('status') if isinstance(entry, dict) else None
        if st not in VALID_STATUS:
            errors.append(f"repair_log.checksums.{sha}.{fpath}.status must be one of {sorted(VALID_STATUS)}, got {st!r} (SCHEMA_INVALID)")

# Cross-check: every SHA in reflog_export.txt must appear in repair_log.orphaned_shas (short form).
reflog_path = Path('reflog_export.txt')
if reflog_path.exists():
    import re as _re
    expected_short_shas = []
    seen_e = set()
    for line in reflog_path.read_text().splitlines():
        m = _re.match(r'^([a-f0-9]{7,40})\s', line)
        if m:
            short = m.group(1)[:7]
            if short not in seen_e:
                seen_e.add(short)
                expected_short_shas.append(short)
    actual_orphans = repair_log.get('orphaned_shas') or []
    actual_short = [s[:7] if isinstance(s, str) else s for s in actual_orphans]
    if len(actual_orphans) != len(expected_short_shas):
        errors.append(f"repair_log.orphaned_shas has {len(actual_orphans)} entries, reflog_export.txt has {len(expected_short_shas)} (CONTRACT_DRIFT)")
    for i, exp in enumerate(expected_short_shas):
        if i >= len(actual_short) or actual_short[i] != exp:
            actual_value = actual_short[i] if i < len(actual_short) else 'missing'
            errors.append(f"repair_log.orphaned_shas[{i}] expected {exp!r}, got {actual_value!r} (CONTRACT_DRIFT)")
            break

# Run manifest type checks.
run_manifest = load_json('outputs/run_manifest.json')
RM_REQUIRED = {'solver', 'python', 'branches_restored', 'bundle_created'}
missing_rm = RM_REQUIRED - set(run_manifest.keys())
if missing_rm:
    errors.append(f"run_manifest.json missing required keys: {sorted(missing_rm)} (SCHEMA_INVALID)")
if not isinstance(run_manifest.get('branches_restored'), int) or isinstance(run_manifest.get('branches_restored'), bool):
    got_type = type(run_manifest.get('branches_restored')).__name__
    errors.append(f"run_manifest.branches_restored must be integer, got {got_type} (SCHEMA_INVALID)")
if not isinstance(run_manifest.get('bundle_created'), bool):
    got_type = type(run_manifest.get('bundle_created')).__name__
    errors.append(f"run_manifest.bundle_created must be boolean, got {got_type} (SCHEMA_INVALID)")
if not isinstance(run_manifest.get('solver'), str) or not run_manifest.get('solver'):
    errors.append("run_manifest.solver must be a non-empty string (SCHEMA_INVALID)")
if not isinstance(run_manifest.get('python'), str) or not run_manifest.get('python'):
    errors.append("run_manifest.python must be a non-empty string (SCHEMA_INVALID)")
# Cross-file consistency: run_manifest.branches_restored must match repair_log.refs_restored count.
if isinstance(run_manifest.get('branches_restored'), int) and not isinstance(run_manifest.get('branches_restored'), bool):
    expected_count = len(repair_log.get('refs_restored') or {})
    if run_manifest['branches_restored'] != expected_count:
        actual_count = run_manifest['branches_restored']
        errors.append(f"run_manifest.branches_restored ({actual_count}) must equal len(repair_log.refs_restored) ({expected_count}) (CONTRACT_DRIFT)")

# Bundle refs must match the contract, not just repair_log.json.
if not errors and expected_refs_path.exists():
    expected_refs = load_json(expected_refs_path)
    with tempfile.TemporaryDirectory() as td:
        mirror = str(Path(td) / 'repo.git')
        clone = git(['clone', '--mirror', 'outputs/repaired_repo.bundle', mirror])
        if clone.returncode == 0:
            for ref, expected_sha in expected_refs.items():
                rev = git(['rev-parse', '--verify', ref], cwd=mirror)
                actual = rev.stdout.strip()
                if rev.returncode != 0 or actual != expected_sha:
                    errors.append(f'bundle {ref}: expected {expected_sha}, got {actual} (TEST_FAIL)')

# Determinism: if the submitted solver is present, rerun from a clean state and compare outputs.
def bundle_signature(bundle_path):
    with tempfile.TemporaryDirectory() as td:
        mirror = str(Path(td) / 'repo.git')
        clone = git(['clone', '--mirror', bundle_path, mirror])
        if clone.returncode != 0:
            return {'clone_error': clone.stderr.strip()}
        refs = git(['show-ref', '--heads'], cwd=mirror).stdout.strip().splitlines()
        ref_map = sorted(line.split()[::-1] for line in refs if line.strip())
        histories = {}
        for ref, sha in ref_map:
            histories[ref] = git(['rev-list', ref], cwd=mirror).stdout.strip().splitlines()
        fsck = git(['fsck', '--connectivity-only'], cwd=mirror)
        return {'refs': ref_map, 'histories': histories, 'fsck_code': fsck.returncode, 'fsck_stderr': fsck.stderr.strip()}

def rmtree_force(path):
    def _rm_readonly(func, item, exc_info):
        try:
            os.chmod(item, stat.S_IWRITE)
            func(item)
        except Exception:
            pass
    shutil.rmtree(path, ignore_errors=False, onerror=_rm_readonly) if Path(path).exists() else None

if not errors and Path('solve.py').exists():
    json_paths = ['outputs/repair_log.json', 'outputs/commit_graph_report.json', 'outputs/run_manifest.json']
    before_json = {p: Path(p).read_bytes() for p in json_paths}
    before_sig = bundle_signature('outputs/repaired_repo.bundle')
    rmtree_force('outputs')
    rmtree_force('recovery_worktree')
    rerun = subprocess.run([sys.executable, 'solve.py'], capture_output=True, text=True, encoding='utf-8', errors='replace')
    if rerun.returncode != 0:
        errors.append(f'solve.py rerun exited {rerun.returncode}: {rerun.stderr.strip()} (NON_DETERMINISTIC_OUTPUT)')
    else:
        for p, old_bytes in before_json.items():
            new_path = Path(p)
            if not new_path.exists():
                errors.append(f'{p} missing after deterministic rerun (NON_DETERMINISTIC_OUTPUT)')
            elif new_path.read_bytes() != old_bytes:
                errors.append(f'{p} changed after deterministic rerun (NON_DETERMINISTIC_OUTPUT)')
        after_sig = bundle_signature('outputs/repaired_repo.bundle')
        if after_sig != before_sig:
            errors.append('repaired_repo.bundle clone signature changed after deterministic rerun (NON_DETERMINISTIC_OUTPUT)')

if errors:
    for e in errors:
        print(f"FAIL: {e}")
    sys.exit(1)

print("VERIFY PASS: All checks ok")
sys.exit(0)