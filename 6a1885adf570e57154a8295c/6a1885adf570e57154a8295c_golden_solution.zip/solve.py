#!/usr/bin/env python3
"""Solve: Recover orphaned commits from git bundle using reflog."""
import sys, json, subprocess, tempfile, os, re, stat
from pathlib import Path

OUT_DIR = Path('outputs')
OUT_DIR.mkdir(parents=True, exist_ok=True)
import platform
GIT = 'git.exe' if platform.system() == 'Windows' else 'git'

def git(args, cwd=None):
    return subprocess.run([GIT] + args, capture_output=True, text=True, encoding='utf-8', errors='replace', cwd=cwd)

def git_ok(args, cwd=None):
    r = git(args, cwd)
    return r.returncode == 0 and not r.stderr.strip()

# ---- Parse inputs ----
object_store = Path('orphaned_object_store')
after_bundle = Path('repo_after_force.bundle')
reflog_txt = Path('reflog_export.txt').read_text()
spec = json.loads(Path('commit_graph_spec.json').read_text())
expected_checksums = json.loads(Path('expected_file_checksums.json').read_text())
expected_refs = json.loads(Path('expected_refs.json').read_text())

# Extract orphaned SHAs from reflog in evidence order for deterministic output
reflog_shas = []
seen_reflog_shas = set()
for line in reflog_txt.strip().splitlines():
    m = re.match(r'^([a-f0-9]{7,40})\s', line)
    if m and m.group(1) not in seen_reflog_shas:
        seen_reflog_shas.add(m.group(1))
        reflog_shas.append(m.group(1))

orphaned = reflog_shas
if not orphaned:
    orphaned = next(iter(spec.get("branches", {}).values()), {}).get("orphaned_commits", [])

# ---- Step 1: Create recovery repo from after-bundle, then graft in dangling loose objects ----
recovery = Path('recovery_worktree')
if recovery.exists():
    import shutil
    def _rm_readonly(func, path, exc_info):
        try:
            os.chmod(path, stat.S_IWRITE)
            func(path)
        except Exception:
            pass
    shutil.rmtree(recovery, onerror=_rm_readonly)
# The after-bundle supplies the surviving refs; orphaned_object_store supplies unreachable objects with no refs.
clone_r = git(['clone', str(after_bundle), str(recovery)])
if clone_r.returncode != 0:
    print("FAIL: could not clone after_bundle")
    (OUT_DIR / 'run_manifest.json').write_text(json.dumps({
        "solver": "solve.py", "status": "failed",
        "error": "after_bundle_invalid",
        "details": clone_r.stderr.strip()
    }, indent=2))
    sys.exit(1)

object_git = object_store / '.git'
object_objects = object_git / 'objects'
if not object_objects.exists():
    print("FAIL: orphaned_object_store/.git/objects is missing")
    (OUT_DIR / 'run_manifest.json').write_text(json.dumps({
        "solver": "solve.py", "status": "failed",
        "error": "missing_object_store",
        "details": str(object_objects)
    }, indent=2))
    sys.exit(1)

import shutil
dest_objects = recovery / '.git' / 'objects'
for item in object_objects.iterdir():
    dest = dest_objects / item.name
    if item.is_dir():
        shutil.copytree(item, dest, dirs_exist_ok=True)
    elif item.is_file():
        shutil.copy2(item, dest)

# Force Git to surface the grafted unreachable commits; lost-found files are not used as truth.
fsck_r = git(['fsck', '--lost-found'], cwd=str(recovery))
if fsck_r.returncode != 0:
    print("WARN: git fsck --lost-found reported issues:", (fsck_r.stdout + fsck_r.stderr)[:300])

# ---- Step 2: Restore branch refs to expected SHAs ----
restored = {}
for ref, expected_sha in expected_refs.items():
    short = expected_sha[:7]
    # Check if the commit exists in the cloned repo
    cat_r = git(["cat-file", "-e", expected_sha], cwd=str(recovery))
    if cat_r.returncode != 0:
        print(f"Commit {expected_sha} not found in bundle — skipping {ref}")
        continue
    # Restore the ref — git update-ref creates or overwrites
    ur_r = git(["update-ref", ref, expected_sha], cwd=str(recovery))
    if ur_r.returncode == 0:
        restored[ref] = expected_sha
        print(f"Restored {ref} -> {expected_sha}")

# ---- Step 4: Verify reachability ----
graph_report = {'branches': {}}
for ref, info in spec.get('branches', {}).items():
    tip = info['expected_tip']
    rl_r = git(["rev-list", "--ancestry-path", f"{tip}^..{tip}"], cwd=str(recovery))
    ancestors_raw = git(['rev-list', tip], cwd=str(recovery)).stdout.strip().splitlines()[:20]
    ancestors = [s[:7] for s in ancestors_raw]
    expected_ancestors_short = [s[:7] for s in info.get('expected_ancestors', [])]
    ancestors_set = set(ancestors)
    all_found = all(ea in ancestors_set for ea in expected_ancestors_short)
    graph_report['branches'][ref] = {
        "tip": tip,
        "expected_ancestors": expected_ancestors_short,
        "found_ancestors": ancestors,
        "all_reachable": all_found
    }
(OUT_DIR / 'commit_graph_report.json').write_text(json.dumps(graph_report, indent=2))

# ---- Step 5: Check file checksums at recovered commits ----
# Use git rev-parse sha:fpath to get the blob hash at that exact commit
# This works even when the file is not checked out on disk
checksum_results = {}
for sha, files in expected_checksums.items():
    checksum_results[sha] = {}
    for fpath, expected_hash in files.items():
        rev_r = git(["rev-parse", f"{sha}:{fpath}"], cwd=str(recovery))
        if rev_r.returncode != 0:
            checksum_results[sha][fpath] = {'status': 'file_not_found', 'expected': expected_hash}
        else:
            actual = rev_r.stdout.strip()
            match = actual == expected_hash
            checksum_results[sha][fpath] = {'status': 'match' if match else 'mismatch', 'expected': expected_hash, 'actual': actual}

# ---- Step 6: Create repaired bundle ----
bundle_path = str((OUT_DIR / "repaired_repo.bundle").resolve())
bundle_r = git(["bundle", "create", bundle_path, "--all"], cwd=str(recovery))
bundle_ok = bundle_r.returncode == 0
if not bundle_ok: print("bundle stderr:", bundle_r.stderr[:300])

# ---- Step 7: Repair log ----
repair_log = {
    "branches_restored": list(restored.keys()),
    "refs_expected": expected_refs,
    "refs_restored": restored,
    "all_refs_restored": len(restored) == len(expected_refs),
    "orphaned_shas": [s[:7] for s in orphaned],
    "bundle_created": bundle_ok,
    "checksums": checksum_results,
}
(OUT_DIR / 'repair_log.json').write_text(json.dumps(repair_log, indent=2))

# ---- Step 8: Run manifest ----
(OUT_DIR / 'run_manifest.json').write_text(json.dumps({
    "solver": "solve.py",
    "python": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
    "branches_restored": len(restored),
    "bundle_created": bundle_ok,
}, indent=2))

print(f"Done. Restored {len(restored)} refs, bundle ok: {bundle_ok}")