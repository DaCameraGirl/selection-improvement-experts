# Reference Solution

- `solve.py` — reference implementation.
- `verify.py` — deterministic verifier for the reference outputs.
- `outputs/` — expected outputs produced by running `solve.py` against the task fixtures.
